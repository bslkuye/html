import Nav from './Nav.js';
import NewsList from './NewsList.js';

export let category = {
  name: 'all',
  apiKey: '7a827ebdea74439bba6ec28dcdff138a',
};

export { Nav, NewsList };
