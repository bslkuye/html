import calendar from "./calender.js";

document.querySelectorAll('.calender-container').forEach(calendar);